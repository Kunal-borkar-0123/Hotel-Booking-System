package com.shbs.common.customer;

import com.shbs.common.jpa.Jpa8Repository;

public interface CustomerRepository extends Jpa8Repository<Customer, Integer> {
}
