package com.shbs.admin.user.authority;

public enum Role {
    ADMIN
}
